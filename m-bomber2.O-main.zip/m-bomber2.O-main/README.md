
# MASTER-BOMBER2.O

MASTER-BOMBER2.O is a Bash code Which can help you to prank your friends. By using this tool You Can Send Anonymous Email and Custom Email and send huge amount of sms , call , Whatsapp and email to your friends.


## Appendix

Automatic update when new update available

## Features

- Colourful interface
- API problem solved
- New Anonymous Email updated
- Cross platform

## Screenshots

![App Screenshot](https://github.com/jatinkalwar/m-bomber2.O/blob/main/Additional/Screenshot_2023-03-07-19-57-50-53_84d3000e3f4017145260f7618db1d683.jpg) ![App Screenshot](https://github.com/jatinkalwar/m-bomber2.O/blob/main/Additional/Screenshot_2023-03-07-19-57-58-87_84d3000e3f4017145260f7618db1d683.jpg) ![App Screenshot](https://github.com/jatinkalwar/m-bomber2.O/blob/main/Additional/Screenshot_2023-04-28-10-39-22-21_84d3000e3f4017145260f7618db1d683.jpg)
## Authors

- [@theJatinKalwar](https://www.github.com/jatinkalwar)


##  Termux Installation

Install Master-Bomber2.O in Termux

```bash
apt update -y && apt upgrade -y
pkg install git -y 
pkg install wget -y
pkg install pv -y
pkg install figlet -y
pkg install python3 -y
pip install colorama
git clone https://github.com/jatinkalwar/m-bomber2.O
cd m-bomber2.O
bash bomber.sh
```
##  Termux Single Line Installation

```bash
apt upgrade -y ; apt update -y ; pkg install git -y ; pkg install wget -y ; pkg install pv -y ; pkg install python3 ; pip install colorama ; pkg install figlet -y ; git clone https://GitHub.com/jatinkalwar/m-bomber2.O ; cd m-bomber2.O ; bash bomber.sh
```

##  Linux Installation

Install Master-Bomber2.O in Linux

```bash
sudo apt-get update -y && sudo apt-get upgrade -y
sudo apt install wget -y
sudo apt install pv -y
sudo apt install python3 -y
sudo apt install figlet -y
sudo pip install colorama
git clone https://github.com/jatinkalwar/m-bomber2.O
cd m-bomber2.O
bash bomber.sh
```

##  Linux Single Line Installation

```bash
sudo apt-get upgrade -y ; sudo apt-get update -y ; sudo apt install wget -y ; sudo apt install python3 -y ; sudo apt install pv -y ; sudo pip install colorama ; sudo apt install figlet -y ; git clone https://GitHub.com/jatinkalwar/m-bomber2.O ; cd ; ls ; cd m-bomber2.O ; bash bomber.sh
```
    
## FAQ

#### Tested Platform??

Termux , Kali Linux , Ubuntu and Parrot Security.

#### International Bomber?

Indian, Pakistan and Bangladesh Bomber but International Bomber Coming Soon


## Feedback

If you have any feedback, please reach out to us at instagram.com/Yourhackinghouse

### Visitors :

![Visitor Count](https://profile-counter.glitch.me/jatinkalwar/count.svg)
