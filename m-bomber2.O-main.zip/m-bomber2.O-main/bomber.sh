python $HOME/m-bomber2.O/mod.py
python $HOME/m-bomber2.O/bomb.py
